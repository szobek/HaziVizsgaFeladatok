package feladat03;

public class Work {
	private String name;
	private int workHour;

	public Work(String name, int workHour) {
		super();
		this.name = name;
		this.workHour = workHour;
	}

	public String getName() {
		return name;
	}

	public int getWorkHour() {
		return workHour;
	}

}
